const Persona = require('./modelo/persona');

// Obtiene todos los objetos Persona de la base de datos
exports.getPersona = async function (req, res) {
  try {
    const personas = await Persona.find().lean();
    res.json(personas);
  } catch (err) {
    console.error(err);
    res.status(500).send(err);
  }
};

// Guarda un objeto Persona en base de datos
exports.setPersona = async function (req, res) {
  try {
    await Persona.create({
      nombre: req.body.nombre,
      apellido: req.body.apellido,
      edad: req.body.edad
    });

    // Obtiene y devuelve todas las personas tras crear una de ellas
    const personas = await Persona.find().lean();
    res.json(personas);
  } catch (err) {
    console.error(err);
    res.status(500).send(err);
  }
};

// Modificamos un objeto Persona de la base de datos
exports.updatePersona = async function (req, res) {
  try {
    await Persona.findByIdAndUpdate(
      req.params.persona_id,
      {
        nombre: req.body.nombre,
        apellido: req.body.apellido,
        edad: req.body.edad
      },
      { runValidators: true }
    );

    // Obtiene y devuelve todas las personas tras modificar una de ellas
    const personas = await Persona.find().lean();
    res.json(personas);
  } catch (err) {
    console.error(err);
    res.status(500).send(err);
  }
};

// Elimino un objeto Persona de la base de Datos
exports.removePersona = async function (req, res) {
  try {
    await Persona.findByIdAndDelete(req.params.persona_id);

    // Obtiene y devuelve todas las personas tras borrar una de ellas
    const personas = await Persona.find().lean();
    res.json(personas);
  } catch (err) {
    console.error(err);
    res.status(500).send(err);
  }
};