const path = require('path');
const Controller = require('./controller');

module.exports = function(app) {

  // --- API ---
  app.get('/api/persona', Controller.getPersona);
  app.post('/api/persona', Controller.setPersona);
  app.put('/api/persona/:persona_id', Controller.updatePersona);
  app.delete('/api/persona/:persona_id', Controller.removePersona);

  // --- FRONT (catch-all) ---
  app.use((req, res) => {
    res.sendFile(path.join(__dirname, '..', 'angular', 'index.html'));
  });
};