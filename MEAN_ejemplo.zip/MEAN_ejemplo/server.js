const express = require('express');
const mongoose = require('mongoose');
const morgan = require('morgan');
const methodOverride = require('method-override');

const app = express();
const port = process.env.PORT || 8080;

mongoose.connect('mongodb://localhost:27017/MeanExample')
  .then(() => console.log('Conectado a MongoDB'))
  .catch(err => console.error('Error conectando a MongoDB:', err));

app.use(express.static(__dirname + '/angular'));

app.use(morgan('dev'));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(methodOverride());

require('./app/routes.js')(app);

app.listen(port, () => {
  console.log(`Servidor ejecutándose en http://localhost:${port}`);
});

app.get('/favicon.ico', (req, res) => res.status(204).end());