angular.module('MainApp', [])
  .controller('mainController', function($scope, $http) {

    $scope.newPersona = {};
    $scope.personas = [];
    $scope.selected = false;

    // Helper: headers JSON
    const jsonConfig = {
      headers: { 'Content-Type': 'application/json' }
    };

    // Cargar todas las personas
    function cargarPersonas() {
      $http.get('/api/persona')
        .then(function(res) {
          $scope.personas = res.data;
        })
        .catch(function(err) {
          console.log('Error:', err);
        });
    }

    cargarPersonas();

    // Registrar
    $scope.registrarPersona = function() {
      $http.post('/api/persona', $scope.newPersona, jsonConfig)
        .then(function(res) {
          $scope.newPersona = {};
          $scope.personas = res.data;
          $scope.selected = false;
        })
        .catch(function(err) {
          console.log('Error:', err);
        });
    };

    // Modificar
    $scope.modificarPersona = function(persona) {
      // persona puede venir de la tabla; si no, usamos newPersona
      const p = persona || $scope.newPersona;
      if (!p || !p._id) return;

      $http.put('/api/persona/' + p._id, p, jsonConfig)
        .then(function(res) {
          $scope.newPersona = {};
          $scope.personas = res.data;
          $scope.selected = false;
        })
        .catch(function(err) {
          console.log('Error:', err);
        });
    };

    // Borrar
    $scope.borrarPersona = function(persona) {
      const p = persona || $scope.newPersona;
      if (!p || !p._id) return;

      $http.delete('/api/persona/' + p._id)
        .then(function(res) {
          $scope.newPersona = {};
          $scope.personas = res.data;
          $scope.selected = false;
        })
        .catch(function(err) {
          console.log('Error:', err);
        });
    };

    // Seleccionar persona
    $scope.selectPerson = function(persona) {
      // Copia para no editar directamente el objeto de la tabla mientras escribes
      $scope.newPersona = angular.copy(persona);
      $scope.selected = true;
    };

  });